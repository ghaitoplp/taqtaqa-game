# طقطقة — نسخة الهاتف الجاهزة للبناء

هذه النسخة تحتوي على اللعبة داخل Android WebView، وتضم إصلاح نتيجة التصويت:

- إذا كان صاحب أعلى الأصوات جاسوسًا: «فاز المحققون!» ويظهر اسم الجاسوس.
- إذا كان صاحب أعلى الأصوات ليس جاسوسًا: «فاز الجواسيس!».
- إذا تعادلت أعلى الأصوات: «تعادل الأصوات».

## أسهل طريقة من الهاتف: AndroidIDE
1. نزّل AndroidIDE على هاتف Android.
2. استخرج هذا ZIP في مجلد مشاريع AndroidIDE.
3. افتح المجلد كمشروع Android/Gradle.
4. انتظر مزامنة Gradle.
5. اختر Build/Assemble Debug.
6. ثبّت الملف:
   app/build/outputs/apk/debug/app-debug.apk

## بديل: GitHub Actions
المجلد يحتوي على:
.github/workflows/build-apk.yml
بعد رفع المشروع إلى مستودع GitHub، سيقوم GitHub Actions ببناء APK تلقائيًا.
بعد انتهاء البناء افتح Run الناجح ثم نزّل Artifact باسم Taqtaqa-debug-apk، وفك الضغط وستجد app-debug.apk.

ملاحظة: لا تغيّر اسم أو مكان app/src/main/assets/index.html.
